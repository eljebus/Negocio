<?php die("You don't have access to open this file!"); ?>
